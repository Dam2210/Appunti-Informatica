# -*- coding: utf-8 -*-
"""
Created on Thu Dec  9 14:41:08 2021

@author: damia
"""

r = (lambda x, y: x+y+1) (1, 6)

print(r)
